package vo.admin;

import lombok.Getter;

@Getter
public class CalendarInfo {
	private String title;
	private String start;
	private String end;
}
