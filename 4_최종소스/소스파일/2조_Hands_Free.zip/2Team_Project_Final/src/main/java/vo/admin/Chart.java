package vo.admin;

import lombok.Data;

@Data
public class Chart {
	private int m9;
	private int m10;
	private int m11;
	private int m12;
	private int m1;
	private int m2;

	private int s9;
	private int s10;
	private int s11;
	private int s12;
	private int s1;
	private int s2;
}
