package dao.user;

import vo.user.Users;

public interface UserRegisterDao {
	public int insertMember(Users users) ;
}
